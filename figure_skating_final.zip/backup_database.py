#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Скрипт для автоматического резервного копирования базы данных
"""

import os
import shutil
import gzip
from datetime import datetime, timedelta
import sys

def create_backup():
    """Создает резервную копию базы данных"""
    
    # Определяем пути
    db_path = 'figure_skating.db'
    backup_dir = 'backups'
    
    # Создаем папку для бэкапов если её нет
    os.makedirs(backup_dir, exist_ok=True)
    
    # Проверяем существование базы данных
    if not os.path.exists(db_path):
        print(f"❌ База данных {db_path} не найдена!")
        return False
    
    # Создаем имя файла с датой и временем
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_filename = f"figure_skating_backup_{timestamp}.db"
    backup_path = os.path.join(backup_dir, backup_filename)
    
    try:
        # Копируем базу данных
        shutil.copy2(db_path, backup_path)
        print(f"✅ Резервная копия создана: {backup_path}")
        
        # Сжимаем файл для экономии места
        compressed_path = backup_path + '.gz'
        with open(backup_path, 'rb') as f_in:
            with gzip.open(compressed_path, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        
        # Удаляем несжатую копию
        os.remove(backup_path)
        print(f"✅ Сжатая резервная копия: {compressed_path}")
        
        # Очищаем старые бэкапы (старше 30 дней)
        cleanup_old_backups(backup_dir)
        
        return True
        
    except Exception as e:
        print(f"❌ Ошибка при создании резервной копии: {e}")
        return False

def cleanup_old_backups(backup_dir, days_to_keep=30):
    """Удаляет старые резервные копии"""
    try:
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        
        for filename in os.listdir(backup_dir):
            if filename.startswith('figure_skating_backup_') and filename.endswith('.db.gz'):
                file_path = os.path.join(backup_dir, filename)
                file_time = datetime.fromtimestamp(os.path.getctime(file_path))
                
                if file_time < cutoff_date:
                    os.remove(file_path)
                    print(f"🗑️  Удален старый бэкап: {filename}")
        
        print(f"✅ Очистка старых бэкапов завершена (старше {days_to_keep} дней)")
        
    except Exception as e:
        print(f"⚠️  Ошибка при очистке старых бэкапов: {e}")

def list_backups():
    """Показывает список всех резервных копий"""
    backup_dir = 'backups'
    
    if not os.path.exists(backup_dir):
        print("📁 Папка с резервными копиями не найдена")
        return
    
    backups = []
    for filename in os.listdir(backup_dir):
        if filename.startswith('figure_skating_backup_') and filename.endswith('.db.gz'):
            file_path = os.path.join(backup_dir, filename)
            file_time = datetime.fromtimestamp(os.path.getctime(file_path))
            file_size = os.path.getsize(file_path)
            backups.append((filename, file_time, file_size))
    
    if not backups:
        print("📁 Резервные копии не найдены")
        return
    
    # Сортируем по дате (новые сверху)
    backups.sort(key=lambda x: x[1], reverse=True)
    
    print("📋 Список резервных копий:")
    print("-" * 80)
    for filename, file_time, file_size in backups:
        size_mb = file_size / (1024 * 1024)
        print(f"📄 {filename}")
        print(f"   📅 Дата: {file_time.strftime('%Y-%m-%d %H:%M:%S')}")
        print(f"   📊 Размер: {size_mb:.2f} MB")
        print()

def restore_backup(backup_filename):
    """Восстанавливает базу данных из резервной копии"""
    backup_dir = 'backups'
    backup_path = os.path.join(backup_dir, backup_filename)
    
    if not os.path.exists(backup_path):
        print(f"❌ Резервная копия {backup_filename} не найдена!")
        return False
    
    # Создаем резервную копию текущей базы
    current_db = 'figure_skating.db'
    if os.path.exists(current_db):
        emergency_backup = f"{current_db}.emergency_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        shutil.copy2(current_db, emergency_backup)
        print(f"🆘 Создана экстренная копия текущей БД: {emergency_backup}")
    
    try:
        # Распаковываем и восстанавливаем
        with gzip.open(backup_path, 'rb') as f_in:
            with open(current_db, 'wb') as f_out:
                shutil.copyfileobj(f_in, f_out)
        
        print(f"✅ База данных восстановлена из {backup_filename}")
        return True
        
    except Exception as e:
        print(f"❌ Ошибка при восстановлении: {e}")
        return False

if __name__ == '__main__':
    if len(sys.argv) > 1:
        command = sys.argv[1]
        
        if command == 'create':
            create_backup()
        elif command == 'list':
            list_backups()
        elif command == 'restore' and len(sys.argv) > 2:
            restore_backup(sys.argv[2])
        else:
            print("Использование:")
            print("  python backup_database.py create  - создать резервную копию")
            print("  python backup_database.py list    - показать список копий")
            print("  python backup_database.py restore <filename> - восстановить из копии")
    else:
        # По умолчанию создаем резервную копию
        create_backup()
