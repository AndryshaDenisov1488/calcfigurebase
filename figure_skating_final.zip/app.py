#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Flask веб-приложение для управления турнирами по фигурному катанию
"""

from flask import Flask, render_template, request, jsonify, redirect, url_for, session, flash
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_cors import CORS
from functools import wraps
import os
import json
from datetime import datetime
from werkzeug.utils import secure_filename
from detailed_parser import ISUCalcFSParser

app = Flask(__name__)
app.config['SECRET_KEY'] = 'your-secret-key-here-change-in-production'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///figure_skating.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size

# Админские данные (в продакшене лучше использовать переменные окружения)
ADMIN_USERNAME = 'admin'
ADMIN_PASSWORD = 'admin123'  # Смените пароль в продакшене!

# Создаем папку для загрузок
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

db = SQLAlchemy(app)

# Декоратор для проверки авторизации администратора
def admin_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        if not session.get('admin_logged_in'):
            flash('Необходима авторизация администратора', 'error')
            return redirect(url_for('admin_login'))
        return f(*args, **kwargs)
    return decorated_function
migrate = Migrate(app, db)
CORS(app)

# Модели базы данных
class Event(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    external_id = db.Column(db.String(50), unique=True)
    name = db.Column(db.String(200), nullable=False)
    long_name = db.Column(db.String(200))
    place = db.Column(db.String(100))
    begin_date = db.Column(db.Date)
    end_date = db.Column(db.Date)
    venue = db.Column(db.String(100))
    language = db.Column(db.String(10))
    event_type = db.Column(db.String(10))
    competition_type = db.Column(db.String(10))
    status = db.Column(db.String(10))
    calculation_time = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    categories = db.relationship('Category', backref='event', lazy=True)

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    external_id = db.Column(db.String(50))
    event_id = db.Column(db.Integer, db.ForeignKey('event.id'), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    tv_name = db.Column(db.String(200))
    num_entries = db.Column(db.Integer)
    num_participants = db.Column(db.Integer)
    level = db.Column(db.String(10))
    gender = db.Column(db.String(10))
    category_type = db.Column(db.String(10))
    status = db.Column(db.String(10))
    
    segments = db.relationship('Segment', backref='category', lazy=True)
    participants = db.relationship('Participant', backref='category', lazy=True)

class Segment(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    name = db.Column(db.String(200), nullable=False)
    tv_name = db.Column(db.String(200))
    short_name = db.Column(db.String(50))
    segment_type = db.Column(db.String(10))
    factor = db.Column(db.Float)
    status = db.Column(db.String(10))
    
    performances = db.relationship('Performance', backref='segment', lazy=True)

class Club(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    short_name = db.Column(db.String(100))
    place = db.Column(db.String(100))
    status = db.Column(db.String(10))
    club_type = db.Column(db.String(10))
    
    athletes = db.relationship('Athlete', backref='club', lazy=True)

class Athlete(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    external_id = db.Column(db.String(50))
    first_name = db.Column(db.String(100), nullable=False)
    last_name = db.Column(db.String(100), nullable=False)
    patronymic = db.Column(db.String(100))
    full_name = db.Column(db.String(200))  # Полное ФИО для жирного отображения
    short_name = db.Column(db.String(200))  # Краткое имя для нижней строки
    birth_date = db.Column(db.Date)
    gender = db.Column(db.String(10))
    nationality = db.Column(db.String(10))
    club_id = db.Column(db.Integer, db.ForeignKey('club.id'))
    status = db.Column(db.String(10))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    participants = db.relationship('Participant', backref='athlete', lazy=True)
    
    # Уникальный индекс для сопоставления спортсменов
    __table_args__ = (
        db.Index('idx_athlete_match', 'first_name', 'last_name', 'birth_date'),
    )

class Participant(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    athlete_id = db.Column(db.Integer, db.ForeignKey('athlete.id'), nullable=False)
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'), nullable=False)
    entry_number = db.Column(db.Integer)
    total_points = db.Column(db.Float)
    total_place = db.Column(db.Integer)
    index = db.Column(db.Integer)
    status = db.Column(db.String(10))
    
    performances = db.relationship('Performance', backref='participant', lazy=True)

class Performance(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    participant_id = db.Column(db.Integer, db.ForeignKey('participant.id'), nullable=False)
    segment_id = db.Column(db.Integer, db.ForeignKey('segment.id'), nullable=False)
    index = db.Column(db.Integer)
    status = db.Column(db.String(10))
    qualification = db.Column(db.String(10))
    start_time = db.Column(db.Time)
    duration = db.Column(db.Time)
    judge_time = db.Column(db.Time)
    place = db.Column(db.Integer)
    points = db.Column(db.Float)
    total_1 = db.Column(db.Float)
    result_1 = db.Column(db.Float)
    total_2 = db.Column(db.Float)
    result_2 = db.Column(db.Float)
    judge_scores = db.Column(db.Text)  # JSON строка с оценками судей

# Маршруты
@app.route('/')
def index():
    """Главная страница"""
    events = Event.query.order_by(Event.begin_date.desc()).limit(10).all()
    return render_template('index.html', events=events)

@app.route('/upload', methods=['GET', 'POST'])
@admin_required
def upload_file():
    """Загрузка и парсинг XML файла"""
    if request.method == 'POST':
        if 'file' not in request.files:
            return jsonify({'error': 'Файл не выбран'}), 400
        
        file = request.files['file']
        if file.filename == '':
            return jsonify({'error': 'Файл не выбран'}), 400
        
        # Проверяем расширение файла (поддерживаем .xml и .XML)
        if not file.filename.lower().endswith('.xml'):
            return jsonify({'error': f'Неверный формат файла. Ожидается .xml, получен: {file.filename}'}), 400
        
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        
        try:
            file.save(filepath)
            
            # Проверяем, что файл действительно XML
            try:
                import xml.etree.ElementTree as ET
                ET.parse(filepath)
            except ET.ParseError as e:
                os.remove(filepath)
                return jsonify({'error': f'Файл не является корректным XML: {str(e)}'}), 400
            
            # Парсим XML файл
            parser = ISUCalcFSParser(filepath)
            parser.parse()
            
            # Сохраняем данные в базу
            save_to_database(parser)
            
            # Удаляем временный файл
            os.remove(filepath)
            
            return jsonify({
                'success': True,
                'message': f'Файл успешно обработан. Добавлено {len(parser.get_athletes_with_results())} спортсменов.'
            })
            
        except Exception as e:
            # Удаляем временный файл в случае ошибки
            if os.path.exists(filepath):
                os.remove(filepath)
            return jsonify({'error': f'Ошибка обработки файла: {str(e)}'}), 500
    
    return render_template('upload.html')

@app.route('/athletes')
def athletes():
    """Страница со списком спортсменов"""
    search = request.args.get('search', '').strip()
    return render_template('athletes.html', search=search)

@app.route('/athlete/<int:athlete_id>')
def athlete_detail(athlete_id):
    """Детальная страница спортсмена"""
    athlete = Athlete.query.get_or_404(athlete_id)
    
    # Получаем все участия спортсмена
    participations = db.session.query(Event, Category, Participant).join(
        Category, Participant.category_id == Category.id
    ).join(
        Event, Category.event_id == Event.id
    ).filter(
        Participant.athlete_id == athlete_id
    ).order_by(Event.begin_date.desc()).all()
    
    return render_template('athlete_detail.html', 
                         athlete=athlete, 
                         participations=participations)

@app.route('/events')
def events():
    """Страница со списком турниров"""
    events = Event.query.order_by(Event.begin_date.desc()).all()
    return render_template('events.html', events=events)

@app.route('/categories')
def categories():
    """Страница с группировкой по разрядам"""
    category_id = request.args.get('category', type=int)
    event_id = request.args.get('event', type=int)
    
    if category_id:
        # Показываем только конкретную категорию
        categories = Category.query.filter_by(id=category_id).all()
    else:
        # Показываем все категории или фильтруем по турниру
        query = Category.query.join(Event)
        if event_id:
            query = query.filter(Category.event_id == event_id)
        categories = query.order_by(Event.begin_date.desc(), Category.name).all()
    
    events = Event.query.order_by(Event.begin_date.desc()).all()
    return render_template('categories.html', categories=categories, events=events, selected_category=category_id, selected_event=event_id)

@app.route('/event/<int:event_id>')
def event_detail(event_id):
    """Детальная страница турнира"""
    event = Event.query.get_or_404(event_id)
    categories = Category.query.filter_by(event_id=event_id).all()
    
    return render_template('event_detail.html', event=event, categories=categories)

@app.route('/analytics')
def analytics():
    """Страница аналитики"""
    return render_template('analytics.html')

@app.route('/api/statistics')
def api_statistics():
    """API для получения статистики"""
    total_athletes = Athlete.query.count()
    total_events = Event.query.count()
    total_participations = Participant.query.count()
    
    # Статистика по клубам
    club_stats = db.session.query(
        Club.name, 
        db.func.count(Athlete.id).label('athlete_count')
    ).join(Athlete).group_by(Club.id).order_by(
        db.func.count(Athlete.id).desc()
    ).limit(10).all()
    
    return jsonify({
        'total_athletes': total_athletes,
        'total_events': total_events,
        'total_participations': total_participations,
        'top_clubs': [{'name': name, 'count': count} for name, count in club_stats]
    })

@app.route('/api/analytics/top-athletes')
def api_top_athletes():
    """API для получения топ спортсменов"""
    # Топ по количеству участий
    top_by_participations = db.session.query(
        Athlete.id,
        Athlete.full_name,
        Athlete.short_name,
        db.func.count(Participant.id).label('participations'),
        db.func.min(Participant.total_place).label('best_place')
    ).join(Participant).group_by(Athlete.id).order_by(
        db.func.count(Participant.id).desc()
    ).limit(10).all()
    
    # Топ по лучшим результатам
    top_by_results = db.session.query(
        Athlete.id,
        Athlete.full_name,
        Athlete.short_name,
        db.func.min(Participant.total_place).label('best_place'),
        db.func.max(Participant.total_points).label('best_points')
    ).join(Participant).filter(
        Participant.total_place.isnot(None)
    ).group_by(Athlete.id).order_by(
        db.func.min(Participant.total_place).asc()
    ).limit(10).all()
    
    return jsonify({
        'by_participations': [
            {
                'id': a.id,
                'name': a.full_name or f"{a.short_name}",
                'participations': a.participations,
                'best_place': a.best_place
            } for a in top_by_participations
        ],
        'by_results': [
            {
                'id': a.id,
                'name': a.full_name or f"{a.short_name}",
                'best_place': a.best_place,
                'best_points': round(a.best_points / 100, 2) if a.best_points else 0
            } for a in top_by_results
        ]
    })

@app.route('/api/analytics/club-statistics')
def api_club_statistics():
    """API для получения статистики по клубам"""
    # Получаем статистику по клубам с количеством спортсменов
    club_athlete_stats = db.session.query(
        Club.id,
        Club.name,
        db.func.count(Athlete.id).label('athlete_count')
    ).outerjoin(Athlete, Club.id == Athlete.club_id).group_by(
        Club.id, Club.name
    ).all()
    
    # Получаем статистику по участиям для каждого клуба
    club_participation_stats = db.session.query(
        Club.id,
        db.func.count(Participant.id).label('participation_count'),
        db.func.min(Participant.total_place).label('best_place')
    ).join(Athlete, Club.id == Athlete.club_id).outerjoin(
        Participant, Athlete.id == Participant.athlete_id
    ).group_by(Club.id).all()
    
    # Объединяем данные
    participation_dict = {c.id: {'count': c.participation_count, 'best': c.best_place} for c in club_participation_stats}
    
    result = []
    for club in club_athlete_stats:
        participation_data = participation_dict.get(club.id, {'count': 0, 'best': None})
        result.append({
            'id': club.id,
            'name': club.name,
            'athlete_count': club.athlete_count,
            'participation_count': participation_data['count'],
            'best_place': participation_data['best']
        })
    
    # Сортируем по количеству спортсменов
    result.sort(key=lambda x: x['athlete_count'], reverse=True)
    
    return jsonify(result)

@app.route('/api/analytics/category-statistics')
def api_category_statistics():
    """API для получения статистики по категориям"""
    category_stats = db.session.query(
        Category.name,
        Category.gender,
        Category.category_type,
        db.func.count(Participant.id).label('participant_count'),
        db.func.avg(Participant.total_points).label('avg_points')
    ).outerjoin(Participant).group_by(
        Category.name, Category.gender, Category.category_type
    ).order_by(
        db.func.count(Participant.id).desc()
    ).all()
    
    return jsonify([
        {
            'name': c.name,
            'gender': c.gender,
            'type': c.category_type,
            'participant_count': c.participant_count,
            'avg_points': round(c.avg_points / 100, 2) if c.avg_points else 0
        } for c in category_stats
    ])

@app.route('/api/athletes')
def api_athletes():
    """API для получения списка спортсменов с поиском"""
    page = request.args.get('page', 1, type=int)
    per_page = 20
    search = request.args.get('search', '').strip()
    
    # Сортируем спортсменов: сначала по лучшему результату (null в конце), потом по имени
    athletes_query = Athlete.query.outerjoin(Participant).group_by(Athlete.id)
    
    # Добавляем поиск по имени или фамилии (нечувствительный к регистру)
    if search:
        # Создаем фильтры для поиска в разных регистрах
        search_lower = search.strip().lower()
        search_upper = search.strip().upper()
        search_title = search.strip().title()
        
        # Создаем фильтры для всех вариантов регистра
        filters = []
        
        # Поиск в нижнем регистре
        filters.extend([
            Athlete.first_name.like(f"%{search_lower}%"),
            Athlete.last_name.like(f"%{search_lower}%"),
            Athlete.full_name.like(f"%{search_lower}%"),
            Athlete.short_name.like(f"%{search_lower}%")
        ])
        
        # Поиск в верхнем регистре
        filters.extend([
            Athlete.first_name.like(f"%{search_upper}%"),
            Athlete.last_name.like(f"%{search_upper}%"),
            Athlete.full_name.like(f"%{search_upper}%"),
            Athlete.short_name.like(f"%{search_upper}%")
        ])
        
        # Поиск с заглавной буквы
        filters.extend([
            Athlete.first_name.like(f"%{search_title}%"),
            Athlete.last_name.like(f"%{search_title}%"),
            Athlete.full_name.like(f"%{search_title}%"),
            Athlete.short_name.like(f"%{search_title}%")
        ])
        
        # Поиск в исходном регистре
        filters.extend([
            Athlete.first_name.like(f"%{search}%"),
            Athlete.last_name.like(f"%{search}%"),
            Athlete.full_name.like(f"%{search}%"),
            Athlete.short_name.like(f"%{search}%")
        ])
        
        athletes_query = athletes_query.filter(db.or_(*filters))
    
    athletes_query = athletes_query.order_by(
        db.func.min(Participant.total_place).asc().nullslast(),
        Athlete.last_name, 
        Athlete.first_name
    )
    
    athletes = athletes_query.paginate(
        page=page, per_page=per_page, error_out=False
    )
    
    # Формируем данные для JSON ответа
    athletes_data = []
    for athlete in athletes.items:
        # Находим лучший результат
        best_result = None
        if athlete.participants:
            best_result = min([p for p in athlete.participants if p.total_place], 
                            key=lambda x: x.total_place, default=None)
        
        # Находим последнюю категорию
        latest_category = None
        if athlete.participants:
            latest_category = max(athlete.participants, 
                                key=lambda x: x.category.event.begin_date, default=None)
        
        athletes_data.append({
            'id': athlete.id,
            'full_name': athlete.full_name or f"{athlete.last_name} {athlete.first_name}",
            'short_name': athlete.short_name,
            'birth_date': athlete.birth_date.strftime('%d.%m.%Y') if athlete.birth_date else None,
            'gender': athlete.gender,
            'gender_display': 'Женский' if athlete.gender == 'F' else 'Мужской' if athlete.gender == 'M' else '-',
            'category_name': latest_category.category.name if latest_category else None,
            'club_name': athlete.club.name if athlete.club else None,
            'club_id': athlete.club.id if athlete.club else None,
            'participations_count': len(athlete.participants),
            'best_place': best_result.total_place if best_result else None,
            'best_points': round(best_result.total_points / 100, 2) if best_result and best_result.total_points else 0
        })
    
    return jsonify({
        'athletes': athletes_data,
        'pagination': {
            'page': athletes.page,
            'pages': athletes.pages,
            'per_page': athletes.per_page,
            'total': athletes.total,
            'has_next': athletes.has_next,
            'has_prev': athletes.has_prev,
            'next_num': athletes.next_num,
            'prev_num': athletes.prev_num
        },
        'search': search
    })

@app.route('/api/category/<int:category_id>')
def api_category_details(category_id):
    """API для получения деталей категории"""
    category = Category.query.get_or_404(category_id)
    
    # Получаем участников с их результатами
    participants = db.session.query(Participant, Athlete, Club).join(
        Athlete, Participant.athlete_id == Athlete.id
    ).outerjoin(
        Club, Athlete.club_id == Club.id
    ).filter(
        Participant.category_id == category_id
    ).order_by(Participant.total_place.asc().nullslast()).all()
    
    return jsonify({
        'name': category.name,
        'event_name': category.event.name,
        'level': category.level,
        'gender': category.gender,
        'participants_count': len(participants),
        'segments': [{'name': s.name} for s in category.segments],
        'participants': [
            {
                'place': p.total_place,
                'athlete_id': a.id,
                'athlete_name': a.full_name or f"{a.last_name} {a.first_name}",
                'club_name': c.name if c else 'Не указан',
                'points': p.total_points
            }
            for p, a, c in participants
        ]
    })

def save_to_database(parser):
    """Сохраняет данные из парсера в базу данных"""
    
    # Сохраняем событие (проверяем на существование)
    event_data = parser.events[0] if parser.events else {}
    event = Event.query.filter_by(external_id=event_data.get('external_id')).first()
    
    if not event:
        event = Event(
            external_id=event_data.get('external_id'),
            name=event_data.get('name'),
            long_name=event_data.get('long_name'),
            place=event_data.get('place'),
            begin_date=parse_date(event_data.get('begin_date')),
            end_date=parse_date(event_data.get('end_date')),
            venue=event_data.get('venue'),
            language=event_data.get('language'),
            event_type=event_data.get('type'),
            competition_type=event_data.get('competition_type'),
            status=event_data.get('status'),
            calculation_time=event_data.get('calculation_time')
        )
        db.session.add(event)
        db.session.flush()  # Получаем ID события
    
    # Сохраняем клубы (проверяем на существование)
    club_mapping = {}
    for club_data in parser.clubs:
        club = Club.query.filter_by(name=club_data.get('name')).first()
        
        if not club:
            club = Club(
                name=club_data.get('name'),
                short_name=club_data.get('short_name'),
                place=club_data.get('place'),
                status=club_data.get('status'),
                club_type=club_data.get('type')
            )
            db.session.add(club)
            db.session.flush()
        
        club_mapping[club_data['id']] = club.id
    
    # Сохраняем категории
    category_mapping = {}
    for category_data in parser.categories:
        category = Category(
            external_id=category_data.get('external_id'),
            event_id=event.id,
            name=category_data.get('name'),
            tv_name=category_data.get('tv_name'),
            num_entries=int(category_data.get('num_entries', 0)) if category_data.get('num_entries') else None,
            num_participants=int(category_data.get('num_participants', 0)) if category_data.get('num_participants') else None,
            level=category_data.get('level'),
            gender=category_data.get('gender'),
            category_type=category_data.get('type'),
            status=category_data.get('status')
        )
        db.session.add(category)
        db.session.flush()
        category_mapping[category_data['id']] = category.id
    
    # Сохраняем сегменты
    segment_mapping = {}
    for segment_data in parser.segments:
        segment = Segment(
            category_id=category_mapping.get(segment_data.get('category_id')),
            name=segment_data.get('name'),
            tv_name=segment_data.get('tv_name'),
            short_name=segment_data.get('short_name'),
            segment_type=segment_data.get('type'),
            factor=float(segment_data.get('factor', 0)) if segment_data.get('factor') else None,
            status=segment_data.get('status')
        )
        db.session.add(segment)
        db.session.flush()
        segment_mapping[segment_data['id']] = segment.id
    
    # Сохраняем спортсменов и участников
    for participant_data in parser.participants:
        person_data = next((p for p in parser.persons if p['id'] == participant_data['person_id']), None)
        if not person_data:
            continue
        
        # Ищем существующего спортсмена по ФИО и дате рождения
        existing_athlete = Athlete.query.filter_by(
            first_name=person_data.get('first_name_cyrillic') or person_data.get('first_name'),
            last_name=person_data.get('last_name_cyrillic') or person_data.get('last_name'),
            birth_date=parse_date(person_data.get('birth_date'))
        ).first()
        
        if existing_athlete:
            athlete = existing_athlete
        else:
            # Создаем нового спортсмена
            athlete = Athlete(
                external_id=person_data.get('external_id'),
                first_name=person_data.get('first_name_cyrillic') or person_data.get('first_name'),
                last_name=person_data.get('last_name_cyrillic') or person_data.get('last_name'),
                patronymic=person_data.get('patronymic_cyrillic') or person_data.get('patronymic'),
                full_name=person_data.get('full_name'),
                short_name=person_data.get('short_name'),
                birth_date=parse_date(person_data.get('birth_date')),
                gender=person_data.get('gender'),
                nationality=person_data.get('nationality'),
                club_id=club_mapping.get(person_data.get('club_id')),
                status=person_data.get('status')
            )
            db.session.add(athlete)
            db.session.flush()
        
        # Создаем участника
        participant = Participant(
            athlete_id=athlete.id,
            category_id=category_mapping.get(participant_data.get('category_id')),
            entry_number=int(participant_data.get('entry_number', 0)) if participant_data.get('entry_number') else None,
            total_points=float(participant_data.get('total_points', 0)) if participant_data.get('total_points') else None,
            total_place=int(participant_data.get('total_place', 0)) if participant_data.get('total_place') else None,
            index=int(participant_data.get('index', 0)) if participant_data.get('index') else None,
            status=participant_data.get('status')
        )
        db.session.add(participant)
        db.session.flush()
        
        # Сохраняем выступления
        for performance_data in parser.performances:
            if performance_data.get('participant_id') == participant_data['id']:
                performance = Performance(
                    participant_id=participant.id,
                    segment_id=segment_mapping.get(performance_data.get('segment_id')),
                    index=int(performance_data.get('index', 0)) if performance_data.get('index') else None,
                    status=performance_data.get('status'),
                    qualification=performance_data.get('qualification'),
                    start_time=parse_time(performance_data.get('start_time')),
                    duration=parse_time(performance_data.get('duration')),
                    judge_time=parse_time(performance_data.get('judge_time')),
                    place=int(performance_data.get('place', 0)) if performance_data.get('place') else None,
                    points=float(performance_data.get('points', 0)) if performance_data.get('points') else None,
                    total_1=float(performance_data.get('total_1', 0)) if performance_data.get('total_1') else None,
                    result_1=float(performance_data.get('result_1', 0)) if performance_data.get('result_1') else None,
                    total_2=float(performance_data.get('total_2', 0)) if performance_data.get('total_2') else None,
                    result_2=float(performance_data.get('result_2', 0)) if performance_data.get('result_2') else None,
                    judge_scores=json.dumps(performance_data.get('judge_scores', {}))
                )
                db.session.add(performance)
    
    db.session.commit()

def parse_date(date_str):
    """Парсит дату из строки формата YYYYMMDD"""
    if not date_str or len(date_str) != 8:
        return None
    try:
        return datetime.strptime(date_str, '%Y%m%d').date()
    except ValueError:
        return None

def parse_time(time_str):
    """Парсит время из строки формата HH:MM:SS"""
    if not time_str:
        return None
    try:
        return datetime.strptime(time_str, '%H:%M:%S').time()
    except ValueError:
        return None

@app.route('/clubs')
def clubs():
    """Страница со списком всех клубов/школ"""
    return render_template('clubs.html')

@app.route('/api/clubs')
def api_clubs():
    """API для получения списка клубов с количеством участников"""
    clubs_data = db.session.query(
        Club.id,
        Club.name,
        db.func.count(Athlete.id).label('athlete_count'),
        db.func.count(Participant.id).label('participation_count')
    ).outerjoin(Athlete, Club.id == Athlete.club_id).outerjoin(
        Participant, Athlete.id == Participant.athlete_id
    ).group_by(Club.id, Club.name).order_by(
        db.func.count(Athlete.id).desc()
    ).all()
    
    result = []
    for club in clubs_data:
        result.append({
            'id': club.id,
            'name': club.name,
            'athlete_count': club.athlete_count,
            'participation_count': club.participation_count
        })
    
    return jsonify(result)

@app.route('/club/<int:club_id>')
def club_detail(club_id):
    """Страница с детальной информацией о клубе"""
    club = Club.query.get_or_404(club_id)
    
    # Получаем всех спортсменов этого клуба с их участиями
    athletes_with_participations = db.session.query(
        Athlete, Event, Category, Participant
    ).join(Participant, Athlete.id == Participant.athlete_id).join(
        Category, Participant.category_id == Category.id
    ).join(Event, Category.event_id == Event.id).filter(
        Athlete.club_id == club_id
    ).order_by(Event.begin_date.desc(), Athlete.last_name, Athlete.first_name).all()
    
    # Группируем по спортсменам
    athletes_data = {}
    for athlete, event, category, participant in athletes_with_participations:
        if athlete.id not in athletes_data:
            athletes_data[athlete.id] = {
                'athlete': athlete,
                'participations': []
            }
        
        athletes_data[athlete.id]['participations'].append({
            'event': event,
            'category': category,
            'participant': participant
        })
    
    return render_template('club_detail.html', 
                         club=club, 
                         athletes_data=list(athletes_data.values()))

# ==================== АДМИНСКИЕ МАРШРУТЫ ====================

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Страница входа для администратора"""
    if request.method == 'POST':
        username = request.form.get('username')
        password = request.form.get('password')
        
        if username == ADMIN_USERNAME and password == ADMIN_PASSWORD:
            session['admin_logged_in'] = True
            flash('Успешный вход в систему', 'success')
            return redirect(url_for('index'))
        else:
            flash('Неверное имя пользователя или пароль', 'error')
    
    return render_template('admin_login.html')

@app.route('/admin/logout')
def admin_logout():
    """Выход из системы"""
    session.pop('admin_logged_in', None)
    flash('Вы вышли из системы', 'info')
    return redirect(url_for('index'))

if __name__ == '__main__':
    with app.app_context():
        db.create_all()
    app.run(debug=True)

# Для продакшена на Beget
if __name__ != '__main__':
    with app.app_context():
        db.create_all()
