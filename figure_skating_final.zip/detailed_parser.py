#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Детальный парсер XML файла ISUCalcFS для извлечения данных о спортсменах и результатах
"""

import xml.etree.ElementTree as ET
import json
from datetime import datetime
from collections import defaultdict

class ISUCalcFSParser:
    def __init__(self, xml_file):
        self.xml_file = xml_file
        self.tree = None
        self.root = None
        self.events = []
        self.categories = []
        self.segments = []
        self.participants = []
        self.persons = []
        self.clubs = []
        self.performances = []
        
    def parse(self):
        """Основной метод парсинга XML файла"""
        print(f"Парсинг файла: {self.xml_file}")
        
        try:
            self.tree = ET.parse(self.xml_file)
            self.root = self.tree.getroot()
            
            # Парсим основные элементы
            self._parse_events()
            self._parse_categories()
            self._parse_segments()
            self._parse_persons()
            self._parse_clubs()
            self._parse_participants()
            self._parse_performances()
            
            print(f"Парсинг завершен:")
            print(f"  - События: {len(self.events)}")
            print(f"  - Категории: {len(self.categories)}")
            print(f"  - Сегменты: {len(self.segments)}")
            print(f"  - Персоны: {len(self.persons)}")
            print(f"  - Клубы: {len(self.clubs)}")
            print(f"  - Участники: {len(self.participants)}")
            print(f"  - Выступления: {len(self.performances)}")
            
        except ET.ParseError as e:
            print(f"Ошибка парсинга XML: {e}")
        except Exception as e:
            print(f"Ошибка: {e}")
    
    def _parse_events(self):
        """Парсинг событий (турниров)"""
        for event in self.root.findall('.//Event'):
            event_data = {
                'id': event.get('EVT_ID'),
                'external_id': event.get('EVT_EXTDT'),
                'name': event.get('EVT_NAME'),
                'long_name': event.get('EVT_LNAME'),
                'place': event.get('EVT_PLACE'),
                'begin_date': event.get('EVT_BEGDAT'),
                'end_date': event.get('EVT_ENDDAT'),
                'venue': event.get('EVT_R1NAM'),
                'language': event.get('EVT_PLANG'),
                'type': event.get('EVT_TYPE'),
                'competition_type': event.get('EVT_CMPTYP'),
                'status': event.get('EVT_STAT'),
                'calculation_time': event.get('EVT_CALCTM')
            }
            self.events.append(event_data)
    
    def _parse_categories(self):
        """Парсинг категорий (разрядов)"""
        for category in self.root.findall('.//Category'):
            category_data = {
                'id': category.get('CAT_ID'),
                'external_id': category.get('CAT_EXTDT'),
                'event_id': category.get('EVT_ID'),
                'name': category.get('CAT_NAME'),
                'tv_name': category.get('CAT_TVNAME'),
                'num_entries': category.get('CAT_NENT'),
                'num_participants': category.get('CAT_NPAR'),
                'level': category.get('CAT_LEVEL'),
                'gender': category.get('CAT_GENDER'),
                'type': category.get('CAT_TYPE'),
                'status': category.get('CAT_STAT')
            }
            self.categories.append(category_data)
    
    def _parse_segments(self):
        """Парсинг сегментов (программ)"""
        for segment in self.root.findall('.//Segment'):
            segment_data = {
                'id': segment.get('SCP_ID'),
                'category_id': segment.get('CAT_ID'),
                'name': segment.get('SCP_NAME'),
                'tv_name': segment.get('SCP_TVNAME'),
                'short_name': segment.get('SCP_SNAM'),
                'type': segment.get('SCP_TYPE'),
                'factor': segment.get('SCP_FACTOR'),
                'status': segment.get('SCP_STAT')
            }
            self.segments.append(segment_data)
    
    def _parse_persons(self):
        """Парсинг персон (спортсменов, тренеров, судей)"""
        # Парсим Person (судьи, тренеры)
        for person in self.root.findall('.//Person'):
            person_data = {
                'id': person.get('PCT_ID'),
                'type': person.get('PCT_TYPE'),
                'status': person.get('PCT_STAT'),
                'club_id': person.get('PCT_CLBID'),
                'first_name': person.get('PCT_FNAMEC') or person.get('PCT_FNAME'),
                'first_name_cyrillic': person.get('PCT_FNAMEC'),
                'last_name': person.get('PCT_PSNAME'),
                'last_name_cyrillic': person.get('PCT_PSNAME'),
                'patronymic': person.get('PCT_TLNAME'),
                'patronymic_cyrillic': person.get('PCT_TSNAME'),
                'full_name': person.get('PCT_PLNAME'),  # Полное ФИО для жирного отображения
                'short_name': person.get('PCT_PSNAME'),  # Краткое имя для нижней строки
                'gender': person.get('PCT_GENDER'),
                'birth_date': person.get('PCT_BDAY'),
                'nationality': person.get('PCT_NAT'),
                'external_id': person.get('PCT_EXTDT'),
                'title': person.get('PCT_TITLE'),
                'function': person.get('PCT_AFUNCT')
            }
            self.persons.append(person_data)
        
        # Парсим Person_Couple_Team (спортсмены)
        for person in self.root.findall('.//Person_Couple_Team'):
            person_data = {
                'id': person.get('PCT_ID'),
                'type': person.get('PCT_TYPE'),
                'status': person.get('PCT_STAT'),
                'club_id': person.get('PCT_CLBID'),
                'first_name': person.get('PCT_FNAMEC') or person.get('PCT_FNAME'),
                'first_name_cyrillic': person.get('PCT_FNAMEC'),
                'last_name': person.get('PCT_PSNAME'),
                'last_name_cyrillic': person.get('PCT_PSNAME'),
                'patronymic': person.get('PCT_TLNAME'),
                'patronymic_cyrillic': person.get('PCT_TSNAME'),
                'full_name': person.get('PCT_PLNAME'),  # Полное ФИО для жирного отображения
                'short_name': person.get('PCT_PSNAME'),  # Краткое имя для нижней строки
                'gender': person.get('PCT_GENDER'),
                'birth_date': person.get('PCT_BDAY'),
                'nationality': person.get('PCT_NAT'),
                'external_id': person.get('PCT_EXTDT'),
                'title': person.get('PCT_TITLE'),
                'function': person.get('PCT_AFUNCT')
            }
            self.persons.append(person_data)
    
    def _parse_clubs(self):
        """Парсинг клубов"""
        for club in self.root.findall('.//Club'):
            club_data = {
                'id': club.get('PCT_ID'),
                'name': club.get('PCT_PLNAME') or club.get('PCT_CNAME'),
                'short_name': club.get('PCT_SNAME'),
                'place': club.get('PCT_PLNAME'),
                'status': club.get('PCT_STAT'),
                'type': club.get('PCT_TYPE')
            }
            self.clubs.append(club_data)
    
    def _parse_participants(self):
        """Парсинг участников"""
        for participant in self.root.findall('.//Participant'):
            participant_data = {
                'id': participant.get('PAR_ID'),
                'person_id': participant.get('PCT_ID'),
                'category_id': participant.get('CAT_ID'),
                'club_id': participant.get('PAR_CLBID'),
                'entry_number': participant.get('PAR_ENTNUM'),
                'total_points': participant.get('PAR_TPOINT'),
                'total_place': participant.get('PAR_TPLACE'),
                'index': participant.get('PAR_INDEX'),
                'status': participant.get('PAR_STAT')
            }
            self.participants.append(participant_data)
    
    def _parse_performances(self):
        """Парсинг выступлений"""
        for performance in self.root.findall('.//Performance'):
            performance_data = {
                'id': performance.get('PRF_ID'),
                'participant_id': performance.get('PAR_ID'),
                'segment_id': performance.get('SCP_ID'),
                'index': performance.get('PRF_INDEX'),
                'status': performance.get('PRF_STAT'),
                'qualification': performance.get('PRF_QUALIF'),
                'start_time': performance.get('PRF_STRTIM'),
                'duration': performance.get('PRF_DURTIM'),
                'judge_time': performance.get('PRF_JDGTIM'),
                'place': performance.get('PRF_PLACE'),
                'points': performance.get('PRF_POINTS'),
                'total_1': performance.get('PRF_M1TOT'),
                'result_1': performance.get('PRF_M1RES'),
                'total_2': performance.get('PRF_M2TOT'),
                'result_2': performance.get('PRF_M2RES')
            }
            
            # Добавляем оценки судей (PRF_E01J01 - PRF_E20J15)
            judge_scores = {}
            for i in range(1, 21):  # Элементы E01-E20
                for j in range(1, 16):  # Судьи J01-J15
                    attr_name = f'PRF_E{i:02d}J{j:02d}'
                    if performance.get(attr_name):
                        if f'E{i:02d}' not in judge_scores:
                            judge_scores[f'E{i:02d}'] = {}
                        judge_scores[f'E{i:02d}'][f'J{j:02d}'] = performance.get(attr_name)
            
            performance_data['judge_scores'] = judge_scores
            self.performances.append(performance_data)
    
    def get_athletes_with_results(self):
        """Получает спортсменов с их результатами"""
        athletes = []
        
        for participant in self.participants:
            # Находим персону
            person = next((p for p in self.persons if p['id'] == participant['person_id']), None)
            if not person:  # Все персоны в этом файле имеют тип PER
                continue
            
            # Находим клуб
            club = next((c for c in self.clubs if c['id'] == participant['club_id']), None)
            
            # Находим выступления
            performances = [p for p in self.performances if p['participant_id'] == participant['id']]
            
            athlete_data = {
                'participant_id': participant['id'],
                'person_id': person['id'],
                'first_name': person['first_name'],
                'last_name': person['last_name'],
                'patronymic': person['patronymic'],
                'full_name': person.get('last_name_cyrillic', '') + ' ' + person.get('first_name_cyrillic', ''),
                'birth_date': person['birth_date'],
                'gender': person['gender'],
                'nationality': person['nationality'],
                'club': club['name'] if club else None,
                'club_short': club['short_name'] if club else None,
                'total_points': participant['total_points'],
                'total_place': participant['total_place'],
                'performances': performances
            }
            
            athletes.append(athlete_data)
        
        return athletes
    
    def export_to_json(self, filename):
        """Экспорт данных в JSON файл"""
        data = {
            'events': self.events,
            'categories': self.categories,
            'segments': self.segments,
            'athletes': self.get_athletes_with_results(),
            'clubs': self.clubs
        }
        
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        
        print(f"Данные экспортированы в {filename}")

def main():
    parser = ISUCalcFSParser("123pretty.XML")
    parser.parse()
    
    # Получаем спортсменов с результатами
    athletes = parser.get_athletes_with_results()
    
    print(f"\nНайдено спортсменов: {len(athletes)}")
    
    # Показываем первых 5 спортсменов
    for i, athlete in enumerate(athletes[:5]):
        print(f"\n{i+1}. {athlete['first_name']} {athlete['last_name']}")
        print(f"   Дата рождения: {athlete['birth_date']}")
        print(f"   Клуб: {athlete['club']}")
        print(f"   Место: {athlete['total_place']}, Очки: {athlete['total_points']}")
        print(f"   Выступлений: {len(athlete['performances'])}")
    
    # Экспортируем в JSON
    parser.export_to_json("parsed_data_pretty.json")

if __name__ == "__main__":
    main()
