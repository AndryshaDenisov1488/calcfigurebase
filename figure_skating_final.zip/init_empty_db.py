#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Скрипт для создания пустой базы данных для продакшена
"""

from app import app, db
import os

def create_empty_database():
    """Создает пустую базу данных с правильной структурой"""
    
    with app.app_context():
        try:
            # Удаляем существующую базу данных если есть
            db_path = 'figure_skating.db'
            if os.path.exists(db_path):
                os.remove(db_path)
                print(f"🗑️  Удалена существующая база данных: {db_path}")
            
            # Очищаем все таблицы
            db.drop_all()
            print("🗑️  Очищены все таблицы")
            
            # Создаем все таблицы заново
            db.create_all()
            print("✅ Создана пустая база данных с правильной структурой")
            
            # Проверяем созданные таблицы
            from sqlalchemy import inspect
            inspector = inspect(db.engine)
            tables = inspector.get_table_names()
            print(f"📊 Созданы таблицы: {tables}")
            
            # Проверяем что база действительно пустая
            from app import Athlete, Event, Club, Category, Participant, Performance
            
            athlete_count = Athlete.query.count()
            event_count = Event.query.count()
            club_count = Club.query.count()
            category_count = Category.query.count()
            participant_count = Participant.query.count()
            performance_count = Performance.query.count()
            
            print(f"📈 Статистика пустой базы данных:")
            print(f"   - Спортсменов: {athlete_count}")
            print(f"   - Турниров: {event_count}")
            print(f"   - Клубов: {club_count}")
            print(f"   - Категорий: {category_count}")
            print(f"   - Участий: {participant_count}")
            print(f"   - Выступлений: {performance_count}")
            
            if all([athlete_count == 0, event_count == 0, club_count == 0, 
                   category_count == 0, participant_count == 0, performance_count == 0]):
                print("✅ База данных пустая и готова для продакшена!")
                print("📝 Теперь можно загружать XML файлы через веб-интерфейс")
            else:
                print("⚠️  В базе данных есть данные!")
                
        except Exception as e:
            print(f"❌ Ошибка при создании пустой базы данных: {e}")
            return False
    
    return True

if __name__ == '__main__':
    create_empty_database()
