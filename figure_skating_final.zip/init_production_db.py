#!/usr/bin/env python3
"""
Скрипт для инициализации базы данных на продакшене
"""

from app import app, db
import os

def init_production_database():
    """Инициализирует базу данных для продакшена"""
    with app.app_context():
        try:
            # Создаем все таблицы
            db.create_all()
            print("✅ База данных успешно инициализирована!")
            
            # Проверяем таблицы
            from sqlalchemy import inspect
            inspector = inspect(db.engine)
            tables = inspector.get_table_names()
            print(f"📊 Созданы таблицы: {tables}")
            
            # Проверяем количество записей
            from app import Athlete, Event, Club, Category, Participant
            athlete_count = Athlete.query.count()
            event_count = Event.query.count()
            club_count = Club.query.count()
            category_count = Category.query.count()
            participant_count = Participant.query.count()
            
            print(f"📈 Статистика базы данных:")
            print(f"   - Спортсменов: {athlete_count}")
            print(f"   - Турниров: {event_count}")
            print(f"   - Клубов: {club_count}")
            print(f"   - Категорий: {category_count}")
            print(f"   - Участий: {participant_count}")
            
            if athlete_count == 0:
                print("⚠️  База данных пустая. Загрузите XML файл через веб-интерфейс.")
            else:
                print("✅ База данных содержит данные и готова к работе!")
                
        except Exception as e:
            print(f"❌ Ошибка при инициализации базы данных: {e}")

if __name__ == '__main__':
    init_production_database()
